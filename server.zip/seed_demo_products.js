const { db } = require('./config/firebase.config');
const admin = require('firebase-admin');

const demoProducts = [
  {
    productId: "RING-2026-0001",
    productName: "Imperial Solitaire Diamond Ring",
    category: "RING",
    purity: "18K Platinum",
    grossWeight: 8.5,
    netWeight: 8.0,
    stoneWeight: 0.5,
    makingCharge: 1200,
    wastage: 1.5,
    quantity: 12,
    stock: 12,
    purchasePrice: 145000,
    sellingPrice: 185000,
    gst: 3,
    status: "AVAILABLE",
    barcode: "RING-2026-0001",
    imageUrl: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=600&q=80",
    description: "An exquisite 18K Platinum ring featuring a brilliant-cut 1.5 carat central solitaire diamond."
  },
  {
    productId: "NECK-2026-0002",
    productName: "Maharani Kundan Heritage Choker",
    category: "NECKLACE",
    purity: "22K Gold",
    grossWeight: 48.0,
    netWeight: 42.5,
    stoneWeight: 5.5,
    makingCharge: 850,
    wastage: 2.0,
    quantity: 5,
    stock: 5,
    purchasePrice: 280000,
    sellingPrice: 345000,
    gst: 3,
    status: "AVAILABLE",
    barcode: "NECK-2026-0002",
    imageUrl: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=600&q=80",
    description: "Traditional Rajasthani Kundan bridal choker set, handcrafted with intricate meenakari work."
  },
  {
    productId: "EARR-2026-0003",
    productName: "Mayuri Royal Gold Jhumkas",
    category: "EARRING",
    purity: "22K Gold",
    grossWeight: 18.2,
    netWeight: 16.8,
    stoneWeight: 1.4,
    makingCharge: 900,
    wastage: 1.8,
    quantity: 15,
    stock: 15,
    purchasePrice: 95000,
    sellingPrice: 125000,
    gst: 3,
    status: "AVAILABLE",
    barcode: "EARR-2026-0003",
    imageUrl: "https://images.unsplash.com/photo-1630019852942-f89202989a59?auto=format&fit=crop&w=600&q=80",
    description: "Elegant gold jhumkas depicting a dancing peacock, adorned with semi-precious rubies."
  },
  {
    productId: "BANG-2026-0004",
    productName: "Lakshmi Antique Temple Kada",
    category: "BANGLE",
    purity: "22K Gold",
    grossWeight: 31.0,
    netWeight: 28.0,
    stoneWeight: 3.0,
    makingCharge: 750,
    wastage: 1.2,
    quantity: 8,
    stock: 8,
    purchasePrice: 170000,
    sellingPrice: 215000,
    gst: 3,
    status: "AVAILABLE",
    barcode: "BANG-2026-0004",
    imageUrl: "https://images.unsplash.com/photo-1611591475153-294711f5ab22?auto=format&fit=crop&w=600&q=80",
    description: "Classic South Indian temple jewellery kada bangles featuring an embossed Goddess Lakshmi design."
  },
  {
    productId: "BRAC-2026-0005",
    productName: "Elegance Sterling Silver Cuff",
    category: "BRACELET",
    purity: "Silver",
    grossWeight: 24.5,
    netWeight: 24.5,
    stoneWeight: 0.0,
    makingCharge: 350,
    wastage: 0.5,
    quantity: 25,
    stock: 25,
    purchasePrice: 12000,
    sellingPrice: 18500,
    gst: 3,
    status: "AVAILABLE",
    barcode: "BRAC-2026-0005",
    imageUrl: "https://images.unsplash.com/photo-1611591475153-294711f5ab22?auto=format&fit=crop&w=600&q=80",
    description: "Modern minimalist 925 sterling silver open cuff bracelet, suitable for daily premium wear."
  },
  {
    productId: "RING-2026-0006",
    productName: "Princess Cut Sapphire Band",
    category: "RING",
    purity: "18K Gold",
    grossWeight: 6.8,
    netWeight: 6.2,
    stoneWeight: 0.6,
    makingCharge: 1100,
    wastage: 1.0,
    quantity: 2,
    stock: 2, // Low stock demo
    purchasePrice: 62000,
    sellingPrice: 85000,
    gst: 3,
    status: "AVAILABLE",
    barcode: "RING-2026-0006",
    imageUrl: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=600&q=80",
    description: "Beautiful 18K yellow gold band Channel-set with blue princess-cut natural sapphires."
  },
  {
    productId: "NECK-2026-0007",
    productName: "Regal Emerald Drop Necklace",
    category: "NECKLACE",
    purity: "18K Gold",
    grossWeight: 38.4,
    netWeight: 34.0,
    stoneWeight: 4.4,
    makingCharge: 1300,
    wastage: 2.2,
    quantity: 0,
    stock: 0, // Out of stock demo
    purchasePrice: 320000,
    sellingPrice: 420000,
    gst: 3,
    status: "OUT_OF_STOCK",
    barcode: "NECK-2026-0007",
    imageUrl: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=600&q=80",
    description: "Exquisite emerald drop necklace featuring natural Colombian pear-shaped emeralds."
  },
  {
    productId: "EARR-2026-0008",
    productName: "Classic Diamond Stud Earrings",
    category: "EARRING",
    purity: "Platinum",
    grossWeight: 4.2,
    netWeight: 3.8,
    stoneWeight: 0.4,
    makingCharge: 1500,
    wastage: 0.8,
    quantity: 7,
    stock: 7,
    purchasePrice: 110000,
    sellingPrice: 155000,
    gst: 3,
    status: "AVAILABLE",
    barcode: "EARR-2026-0008",
    imageUrl: "https://images.unsplash.com/photo-1630019852942-f89202989a59?auto=format&fit=crop&w=600&q=80",
    description: "Flawless round-cut diamond solitaire studs, set in 950 pure Platinum basket mountings."
  },
  {
    productId: "BANG-2026-0009",
    productName: "Diamond Eternity Wave Bangle",
    category: "BANGLE",
    purity: "18K Gold",
    grossWeight: 22.8,
    netWeight: 20.2,
    stoneWeight: 2.6,
    makingCharge: 1400,
    wastage: 1.6,
    quantity: 10,
    stock: 10,
    purchasePrice: 210000,
    sellingPrice: 285000,
    gst: 3,
    status: "AVAILABLE",
    barcode: "BANG-2026-0009",
    imageUrl: "https://images.unsplash.com/photo-1611591475153-294711f5ab22?auto=format&fit=crop&w=600&q=80",
    description: "Stunning wave-shaped bangle in 18K white gold, fully paved with micro-diamonds."
  },
  {
    productId: "BRAC-2026-0010",
    productName: "Floral Diamond Gold Bracelet",
    category: "BRACELET",
    purity: "18K Gold",
    grossWeight: 14.5,
    netWeight: 12.0,
    stoneWeight: 2.5,
    makingCharge: 1250,
    wastage: 1.4,
    quantity: 4,
    stock: 4,
    purchasePrice: 90000,
    sellingPrice: 135000,
    gst: 3,
    status: "AVAILABLE",
    barcode: "BRAC-2026-0010",
    imageUrl: "https://images.unsplash.com/photo-1611591475153-294711f5ab22?auto=format&fit=crop&w=600&q=80",
    description: "Charming floral-motif link bracelet, featuring sparkling pave diamonds in 18K yellow gold."
  }
];

const seedDatabase = async () => {
  console.log("🌱 Seeding 10 Professional Jewellery Products...");
  
  try {
    const productsRef = db.collection('products');
    const categoriesRef = db.collection('categories');
    const transactionsRef = db.collection('inventory_transactions');

    // 1. Clear existing products (optional, but ensures clean slate)
    console.log("🧹 Clearing old products/categories/transactions...");
    const oldProducts = await productsRef.get();
    const deleteProductPromises = oldProducts.docs.map(doc => doc.ref.delete());
    await Promise.all(deleteProductPromises);

    const oldCategories = await categoriesRef.get();
    const deleteCatPromises = oldCategories.docs.map(doc => doc.ref.delete());
    await Promise.all(deleteCatPromises);

    const oldTransactions = await transactionsRef.get();
    const deleteTxPromises = oldTransactions.docs.map(doc => doc.ref.delete());
    await Promise.all(deleteTxPromises);

    console.log("✅ Collections cleared!");

    // Aggregate category stats during seeding
    const categoryStats = {};

    for (const product of demoProducts) {
      const serverTimestamp = admin.firestore.FieldValue.serverTimestamp();
      
      const finalProduct = {
        ...product,
        createdAt: serverTimestamp,
        updatedAt: serverTimestamp
      };

      // 2. Add product
      console.log(`📦 Adding Product: ${product.productName} (${product.productId})`);
      await productsRef.add(finalProduct);

      // Track statistics for categories
      const cat = product.category;
      if (!categoryStats[cat]) {
        categoryStats[cat] = {
          totalProducts: 0,
          totalStock: 0,
          totalValue: 0
        };
      }
      categoryStats[cat].totalProducts += 1;
      categoryStats[cat].totalStock += product.stock;
      categoryStats[cat].totalValue += product.sellingPrice * product.stock;

      // 3. Create inventory transaction log
      await transactionsRef.add({
        productId: product.productId,
        type: 'INWARD',
        quantity: product.stock,
        balanceAfter: product.stock,
        date: serverTimestamp,
        performedBy: 'System Seed Script',
        reason: 'Initial Seeding'
      });
    }

    // 4. Write aggregated category data to Firestore
    for (const [catName, stats] of Object.entries(categoryStats)) {
      console.log(`🏷️  Creating Category: ${catName} (Stock: ${stats.totalStock}, Value: ₹${stats.totalValue})`);
      await categoriesRef.add({
        categoryName: catName,
        totalProducts: stats.totalProducts,
        totalStock: stats.totalStock,
        totalValue: stats.totalValue,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        updatedAt: admin.firestore.FieldValue.serverTimestamp()
      });
    }

    console.log("🎉 Seeding Completed Successfully!");
    process.exit(0);
  } catch (error) {
    console.error("❌ Seeding failed:", error);
    process.exit(1);
  }
};

seedDatabase();
