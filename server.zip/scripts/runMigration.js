const admin = require('firebase-admin');
const dotenv = require('dotenv');
const path = require('path');

dotenv.config({ path: path.join(__dirname, '../.env') });

const firebaseConfig = {
  projectId: process.env.FIREBASE_PROJECT_ID || 'md-fashion-software',
  clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
  privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
};

try {
  if (firebaseConfig.clientEmail && firebaseConfig.privateKey) {
    admin.initializeApp({
      credential: admin.credential.cert(firebaseConfig),
    });
  } else {
    admin.initializeApp({
      projectId: firebaseConfig.projectId,
    });
  }
} catch (e) {
  admin.initializeApp({ projectId: 'md-fashion-software' });
}

const db = admin.firestore();

async function migrate() {
  try {
    const snap = await db.collection('orders').get();
    if (snap.empty) {
      console.log("No orders found");
      return;
    }

    const batch = db.batch();
    let count = 0;

    snap.forEach((docSnap) => {
      const data = docSnap.data();
      const docRef = docSnap.ref;

      let needsUpdate = false;
      const updateData = {};

      let determinedSource = '';
      if (data.orderSource) {
        determinedSource = data.orderSource.toUpperCase();
      } else if (data.source) {
        determinedSource = data.source.toUpperCase();
      } else if (docSnap.id.startsWith('INV-')) {
        determinedSource = 'POS';
      } else if (docSnap.id.startsWith('MDF-')) {
        determinedSource = 'WEB';
      } else {
        determinedSource = 'WEB';
      }

      if (determinedSource !== 'WEB' && determinedSource !== 'POS') {
        determinedSource = 'WEB';
      }

      if (data.orderSource !== determinedSource) {
        updateData.orderSource = determinedSource;
        needsUpdate = true;
      }

      if (data.source !== determinedSource) {
        updateData.source = determinedSource;
        needsUpdate = true;
      }

      if (needsUpdate) {
        batch.update(docRef, updateData);
        count++;
      }
    });

    if (count > 0) {
      await batch.commit();
      console.log(`Migrated ${count} documents`);
    } else {
      console.log("No documents needed migration");
    }
  } catch (err) {
    console.error("Error migrating:", err);
  }
}

migrate();
