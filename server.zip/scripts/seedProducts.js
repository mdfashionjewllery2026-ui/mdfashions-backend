const admin = require('firebase-admin');
const dotenv = require('dotenv');
const path = require('path');

dotenv.config({ path: path.join(__dirname, '../.env') });

const firebaseConfig = {
  projectId: process.env.FIREBASE_PROJECT_ID || 'md-fashion-software',
};

if (!admin.apps.length) {
  admin.initializeApp(firebaseConfig);
}

const db = admin.firestore();

async function seedProducts() {
  console.log("Starting product seeding...");
  const productsRef = db.collection('products');
  
  // 1. Delete all existing products
  console.log("Deleting old products...");
  const snapshot = await productsRef.get();
  
  if (!snapshot.empty) {
    const batches = [];
    let batch = db.batch();
    let count = 0;
    
    snapshot.docs.forEach((doc) => {
      batch.delete(doc.ref);
      count++;
      if (count === 490) {
        batches.push(batch.commit());
        batch = db.batch();
        count = 0;
      }
    });
    
    if (count > 0) {
      batches.push(batch.commit());
    }
    
    await Promise.all(batches);
    console.log(`Deleted ${snapshot.size} old products.`);
  }

  // 2. Add new beautiful AI generated products
  console.log("Adding new luxury products...");
  
  const newProducts = [
    {
      productId: 'PRD-GN-001',
      barcode: '890123456001',
      productName: 'Royal 22K Gold Bridal Necklace',
      category: 'NECKLACE',
      stock: 5,
      quantity: 5, // For stock UI
      purchasePrice: 180000,
      sellingPrice: 220000,
      oldPrice: 240000, // For website
      purity: '22K Gold',
      metal: 'gold',
      grossWeight: 45,
      netWeight: 42,
      imageUrl: '/products/gold_necklace.png',
      images: ['/products/gold_necklace.png'],
      badge: 'Bestseller',
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    },
    {
      productId: 'PRD-DR-002',
      barcode: '890123456002',
      productName: 'Platinum Solitaire Diamond Ring',
      category: 'RING',
      stock: 8,
      quantity: 8,
      purchasePrice: 120000,
      sellingPrice: 155000,
      oldPrice: 165000,
      purity: 'Platinum',
      metal: 'diamond',
      grossWeight: 8,
      netWeight: 7.5,
      imageUrl: '/products/diamond_ring.png',
      images: ['/products/diamond_ring.png'],
      badge: 'New Arrival',
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    },
    {
      productId: 'PRD-GB-003',
      barcode: '890123456003',
      productName: 'Traditional 22K Gold Bangles (Set of 2)',
      category: 'BANGLE',
      stock: 12,
      quantity: 12,
      purchasePrice: 210000,
      sellingPrice: 245000,
      oldPrice: 260000,
      purity: '22K Gold',
      metal: 'gold',
      grossWeight: 65,
      netWeight: 62,
      imageUrl: '/products/gold_bangles.png',
      images: ['/products/gold_bangles.png'],
      badge: 'Trending',
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    },
    {
      productId: 'PRD-DE-004',
      barcode: '890123456004',
      productName: 'Elegant Diamond Drop Earrings',
      category: 'EARRING',
      stock: 15,
      quantity: 15,
      purchasePrice: 95000,
      sellingPrice: 125000,
      oldPrice: 140000,
      purity: '18K White Gold',
      metal: 'diamond',
      grossWeight: 12,
      netWeight: 11,
      imageUrl: '/products/diamond_earrings.png',
      images: ['/products/diamond_earrings.png'],
      badge: 'Bestseller',
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    }
  ];

  const addBatch = db.batch();
  newProducts.forEach((prod) => {
    const newRef = productsRef.doc(prod.productId);
    addBatch.set(newRef, prod);
  });
  
  await addBatch.commit();
  console.log("Successfully added 4 new beautiful products with images!");
}

seedProducts()
  .then(() => process.exit(0))
  .catch(console.error);
