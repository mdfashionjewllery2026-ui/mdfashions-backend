/**
 * ============================================================
 * MD Fashion — Firestore Data Cleanup Script
 * Clears demo/old data from:
 *   - orders         (Invoices, Web Sales source)
 *   - packing_queue
 *   - shipping_queue
 *   - customers
 *   - staff
 * ============================================================
 */

const { db } = require('../config/firebase.config');

const COLLECTIONS_TO_CLEAR = [
  'orders',
  'packing_queue',
  'shipping_queue',
  'customers',
  'staff'
];

const deleteCollection = async (collectionName) => {
  console.log(`\n🗑️  Clearing collection: "${collectionName}"...`);
  const ref = db.collection(collectionName);
  let totalDeleted = 0;

  // Delete in batches of 400 to stay within Firestore limits
  while (true) {
    const snapshot = await ref.limit(400).get();
    if (snapshot.empty) break;

    const batch = db.batch();
    snapshot.docs.forEach(doc => batch.delete(doc.ref));
    await batch.commit();

    totalDeleted += snapshot.docs.length;
    console.log(`   ✓ Deleted ${totalDeleted} documents so far...`);
  }

  console.log(`   ✅ "${collectionName}" cleared — ${totalDeleted} documents removed.`);
  return totalDeleted;
};

const runCleanup = async () => {
  console.log('');
  console.log('========================================================');
  console.log('  MD Fashion — Firestore Data Cleanup');
  console.log('========================================================');
  console.log('⚠️  This will permanently delete ALL documents in:');
  COLLECTIONS_TO_CLEAR.forEach(c => console.log(`     • ${c}`));
  console.log('');

  let grandTotal = 0;

  for (const col of COLLECTIONS_TO_CLEAR) {
    try {
      const count = await deleteCollection(col);
      grandTotal += count;
    } catch (err) {
      console.error(`❌ Failed to clear "${col}":`, err.message);
    }
  }

  console.log('');
  console.log('========================================================');
  console.log(`  ✅ CLEANUP COMPLETE — ${grandTotal} total documents deleted.`);
  console.log('========================================================');
  console.log('');
  process.exit(0);
};

runCleanup().catch(err => {
  console.error('💥 Cleanup script crashed:', err);
  process.exit(1);
});
