const { recalculateSummaryDocs } = require('../services/summaryService');

async function run() {
  try {
    await recalculateSummaryDocs();
    console.log("Recalculation complete.");
  } catch (err) {
    console.error("Error:", err);
  }
}

run().then(() => process.exit(0));
