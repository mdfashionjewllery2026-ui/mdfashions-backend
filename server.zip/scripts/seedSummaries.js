const { recalculateSummaryDocs } = require('../services/summaryService');

async function main() {
  console.log('Starting historical sync for dashboard summaries...');
  try {
    await recalculateSummaryDocs();
    console.log('Successfully seeded summaries collection in Firestore!');
    process.exit(0);
  } catch (error) {
    console.error('Failed to seed summaries:', error);
    process.exit(1);
  }
}

main();
